<?php
    ini_set("display_errors","Off"); 
    //hilangkan koma kalau sudah selese
    session_start();
    if (!isset($_SESSION['username'])){
        header("Location:./index.php");
        // header("Location:./login.php?msg=Silahkan Login Dahulu");
    }
    $username=$_SESSION['username'];
    include "connect.php";
    $sql_user = "select * from login where user='$username'";
    $hasil_user = mysqli_query($koneksi, $sql_user);
    $pilih_user=mysqli_fetch_array($hasil_user);
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="assets/images/favicon.png">
    <title>RekomendasiLaptop</title>
    <!-- Bootstrap Core CSS -->
    
    <link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/bootstrap.css" rel="stylesheet">
    <link href="css/dataTables.bootstrap4.min.css" rel="stylesheet">
    
    <script src="js/jquery.min.js"></script>
    
    <script src="js/dataTables.bootstrap4.min.js"></script>
    
    <script src="js/jquery.dataTables.min.js"></script>    
    
    <link href="css/style.css" rel="stylesheet">
    <link href="css/colors/blue.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>
<script language="JavaScript" type="text/JavaScript">
    var newwindow;

    function KonfirmasiHapus(submodule,id) {
        var jawaban;
        jawaban=confirm("Anda Yakin record ini akan dihapus?");
        if(jawaban) 
        {
            location.href=""+submodule+"="+id;
        }
    }
</script>
<body class="fix-header fix-sidebar card-no-border">
    <!-- ============================================================== -->
    <!-- Preloader - style you can find in spinners.css -->
    <!-- ============================================================== -->
    
    <!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
        <!-- ============================================================== -->
        <!-- Topbar header - style you can find in pages.scss -->
        <!-- ============================================================== -->
        <header class="topbar">
            <nav class="navbar top-navbar navbar-toggleable-sm navbar-light">
                <!-- ============================================================== -->
                <!-- Logo -->
                <!-- ============================================================== -->
                <div class="navbar-header">
                    <a class="navbar-brand" href="dashboard.php">
                        <!-- Logo icon --><b>
                            <!--You can put here icon as well // <i class="wi wi-sunset"></i> //-->
                            
                            <!-- Light Logo icon -->
                            
                        </b>
                        <!--End Logo icon -->
                        <!-- Logo text --><span>
                         
                         <!-- Light Logo text -->    
                         <!-- <img src="assets/images/logo-spk.png" class="light-logo" alt="homepage" /> -->
                         
                         <label class="text-light" style="font-weight: bold; font-size: 120%; ">REKOMENDASI LAPTOP</label>
                        </span> </a>
                </div>
                <button class="btn btn-outline-success my-2 my-sm-0"><a href="login.php" class="text-light">Selamat datang <?php echo $username; ?></a></button>
                <!-- ============================================================== -->
                <!-- End Logo -->
                <!-- ============================================================== -->
                <div class="navbar-collapse">
                    <!-- ============================================================== -->
                    <!-- toggle and nav items -->
                    <!-- ============================================================== -->
                    <ul class="navbar-nav mr-auto mt-md-0">
                        <!-- This is  -->
                        <li class="nav-item"> <a class="nav-link nav-toggler hidden-md-up text-muted waves-effect waves-dark" href="javascript:void(0)"><i class="mdi mdi-menu"></i></a> </li>
                        <!-- ============================================================== -->
                        <!-- Search -->
                        <!-- ============================================================== -->
                        
                    </ul>
                    <!-- ============================================================== -->
                    <!-- User profile and search -->
                    <!-- ============================================================== -->
                    
                </div>
            </nav>
        </header>