# topsis-tirtakomputer

Sistem rekomendasi laptop menggunakan metode topsis untuk Tirta Komputer
![alt text](https://drive.google.com/uc?export=view&id=1Mz-F8B67nawn7XIaEaRp8BzJyZsoF0R5)
